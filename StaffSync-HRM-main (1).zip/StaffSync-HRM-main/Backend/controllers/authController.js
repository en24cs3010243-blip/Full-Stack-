const User = require("../models/User");
const jwt = require("jsonwebtoken");

const generateToken = (id, role) => {
    return jwt.sign({ id, role }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES_IN,
    });
};

const Register = async(req, res) => {
    try {
        const { name, email, password, role, department } = req.body;
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: "User already exists" });
        }

        const user = await User.create({ name, email, password, role, department });
        const token = generateToken(user._id, user.role);

        res.status(201).json({
            message: "User registered successfully",
            user: { id: user._id, name: user.name, role: user.role },
            token,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const login = async(req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ message: "Invalid credentials" });

        const isMatch = await user.matchPassword(password);
        if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

        const token = generateToken(user._id, user.role);

        res.status(200).json({
            message: "Login successful",
            user: { id: user._id, name: user.name, role: user.role },
            token,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = { Register, login };